THIS PROJECT IS DEAD. GO TO https://github.com/JoeBanks13/Music-Butt

[![Open Source Music Bot Logo](https://cdn.discordapp.com/attachments/211274061794377729/224402276687675393/OS-MB-Github-Transparent.svg)](https://github.com/developerCodex/musicbot)
<br />
<br />
A Discord music bot you may run yourself with minimal effort and time!

This bot will require: **Node.js, Git, discord.js#indev-old, FFMPEG, ytdl-core, mathjs, Python 2.7 (optional)**, most of these are bundled into the bot, for more information on how to install the bot please check the [wiki](https://github.com/developerCodex/musicbot/wiki/Installation).

If you encounter any **bugs or issues** throughout the process of trying to get your bot running, then please **create an issue on the github**, and we'll check into it, as soon as we can.

---
# Links

[Music Bot Support Server](https://discord.gg/CVyVgap)

[Go here for instructions](https://github.com/developerCodex/musicbot/wiki/Installation)

[Discord.js Documentation](http://discordjs.readthedocs.io/en/8.1.0/index.html)

[Credit](https://github.com/developerCodex/musicbot/wiki/Credit)
