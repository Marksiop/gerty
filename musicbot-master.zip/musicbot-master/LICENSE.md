# developerCodex Music Bot - Terms and conditions

Basically don't distribute the bot without having devs names on it (developerCodex,Joseph,ZelAk312)

Do not modify any code which has been marked by a comment saying it can not be modified

If any of this is done you will be prosecuted. :smile:


MIT License also applies
