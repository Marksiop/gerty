#!/bin/bash
# If you have issues running this try this code
# sudo chmod 777 run.sh
# It is most likely that it will not work when you first use it
echo If you get any issues running this script then read the help in the file
node bot.js
